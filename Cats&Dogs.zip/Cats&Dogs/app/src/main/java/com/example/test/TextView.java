package com.example.test;

class TextView {
    public void setText(String s) {
    }
}
