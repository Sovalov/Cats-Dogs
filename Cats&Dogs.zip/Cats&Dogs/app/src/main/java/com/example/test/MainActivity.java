package com.example.test;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends Activity {

    private TextView mHelloTextView;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mHelloTextView = findViewById(R.id.text1);
    }

    public void OnClick(View view) {
        mHelloTextView.setText("Hello Kitty!");
    }
}

